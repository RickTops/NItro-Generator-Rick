import flask
import colorama
import discord.py
import base64
import time
import auto_py_to_exe2


timestamp(dlc)
  delay: 20 #ms
  time: GMT+2
 

[
Nitro: 
     ammount: "200"
     autoclaim: "true"
     discordTokenChecker: "on"

]

[

    webhookLogs: "false"
    everyonePing: "true"

]